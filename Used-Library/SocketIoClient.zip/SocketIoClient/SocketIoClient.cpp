#include "SocketIoClient.h"

// Constructor/Destructor
SocketIoClient::SocketIoClient() {
    #ifdef SOCKET_IO_PLATFORM_ESP32
        _mutex = xSemaphoreCreateMutex();
    #endif
}

SocketIoClient::~SocketIoClient() {
    #ifdef SOCKET_IO_PLATFORM_ESP32
        if(_socketTask) {
            vTaskDelete(_socketTask);
        }
        vSemaphoreDelete(_mutex);
    #endif
}

// Connection Methods
void SocketIoClient::beginSSL(const char* host, const int port, const char* url, const char* fingerprint) {
    SOCKETIOCLIENT_DEBUG("Initializing SSL connection...\n");
    
    #ifdef SOCKET_IO_PLATFORM_ESP32
        if(fingerprint && strlen(fingerprint) > 0) {
            _sslClient.setFingerprint(fingerprint);
        }
        _webSocket.setClient(&_sslClient);
    #else
        _webSocket.setFingerprint(fingerprint);
    #endif

    _webSocket.beginSSL(host, port, url);
    initialize();
}

void SocketIoClient::begin(const char* host, const int port, const char* url) {
    SOCKETIOCLIENT_DEBUG("Initializing non-SSL connection...\n");
    _webSocket.begin(host, port, url);
    initialize();
}

// Core Functions
void SocketIoClient::loop() {
    lock();
    _webSocket.loop();
    
    // Packet processing
    for(auto packet = _packets.begin(); packet != _packets.end();) {
        if(_webSocket.sendTXT(*packet)) {
            SOCKETIOCLIENT_DEBUG("Packet sent: %s\n", packet->c_str());
            packet = _packets.erase(packet);
        } else {
            ++packet;
        }
    }

    // Ping management
    if(millis() - _lastPing > PING_INTERVAL) {
        _webSocket.sendTXT("2");
        _lastPing = millis();
        SOCKETIOCLIENT_DEBUG("Sent ping\n");
    }
    unlock();
}

// Event Handling
void SocketIoClient::on(const char* event, std::function<void (const char * payload, size_t length)> func) {
    if(event && strlen(event) > 0) {
        _events[event] = func;
    }
}

void SocketIoClient::emit(const char* event, const char* payload) {
    if(!event || strlen(event) == 0) return;

    String msg;
    msg.reserve(strlen(event) + (payload ? strlen(payload) : 0) + 16);
    msg += "42[\"";
    msg += event;
    msg += "\"";
    
    if(payload) {
        msg += ",";
        msg += payload;
    }
    msg += "]";
    
    lock();
    _packets.push_back(msg);
    unlock();
    
    SOCKETIOCLIENT_DEBUG("Queued packet: %s\n", msg.c_str());
}

// WebSocket Event Handler
void SocketIoClient::webSocketEvent(WStype_t type, uint8_t* payload, size_t length) {
    switch(type) {
        case WStype_DISCONNECTED:
            SOCKETIOCLIENT_DEBUG("Disconnected!\n");
            trigger("disconnect", NULL, 0);
            break;
            
        case WStype_CONNECTED:
            SOCKETIOCLIENT_DEBUG("Connected to: %s\n", payload);
            trigger("connect", NULL, 0);
            break;
            
        case WStype_TEXT: {
            String msg((char*)payload);
            if(msg.startsWith("42")) {
                String event = getEventName(msg);
                String data = getEventPayload(msg);
                trigger(event.c_str(), data.c_str(), data.length());
            }
            // Handle other message types
            break;
        }
        
        case WStype_BIN:
            SOCKETIOCLIENT_DEBUG("Received binary data (%d bytes)\n", length);
            break;
            
        case WStype_ERROR:
            SOCKETIOCLIENT_DEBUG("Connection error!\n");
            break;
    }
}

// Helper Functions
const String getEventName(const String& msg) {
    int start = msg.indexOf('"', 4) + 1;
    int end = msg.indexOf('"', start);
    return msg.substring(start, end);
}

const String getEventPayload(const String& msg) {
    int payloadStart = msg.indexOf(',', msg.indexOf('"', 4)) + 1;
    if(payloadStart == 0) return "";
    
    String payload = msg.substring(payloadStart, msg.length() - 1);
    payload.trim();
    if(payload.startsWith("\"")) payload.remove(0, 1);
    if(payload.endsWith("\"")) payload.remove(payload.length()-1);
    return payload;
}

// Security Functions
void SocketIoClient::setAuthorization(const char *user, const char *password) {
    _webSocket.setAuthorization(user, password);
}

#ifdef SOCKET_IO_PLATFORM_ESP32
void SocketIoClient::setCACert(const char* caCert) {
    _sslClient.setCACert(caCert);
}

void SocketIoClient::setCertificate(const char* clientCert, const char* clientKey) {
    _sslClient.setCertificate(clientCert);
    _sslClient.setPrivateKey(clientKey);
}

void SocketIoClient::lowPowerMode(bool enable) {
    if(enable) {
        esp_sleep_enable_timer_wakeup(PING_INTERVAL * 1000);
        esp_light_sleep_start();
    }
}
#endif

// Thread Safety
void SocketIoClient::lock() {
    #ifdef SOCKET_IO_PLATFORM_ESP32
        xSemaphoreTake(_mutex, portMAX_DELAY);
    #endif
}

void SocketIoClient::unlock() {
    #ifdef SOCKET_IO_PLATFORM_ESP32
        xSemaphoreGive(_mutex);
    #endif
}

// Private Initialization
void SocketIoClient::initialize() {
    _webSocket.onEvent([this](WStype_t type, uint8_t* payload, size_t length) {
        this->webSocketEvent(type, payload, length);
    });
    
    #ifdef SOCKET_IO_PLATFORM_ESP32
        xTaskCreatePinnedToCore(
            [](void* param) {
                SocketIoClient* client = static_cast<SocketIoClient*>(param);
                while(true) {
                    client->lock();
                    client->_webSocket.loop();
                    client->unlock();
                    vTaskDelay(10 / portTICK_PERIOD_MS);
                }
            },
            "SocketIO_Task",
            8192,
            this,
            1,
            &_socketTask,
            APP_CPU_NUM
        );
    #endif
    
    _lastPing = millis();
    SOCKETIOCLIENT_DEBUG("Initialization complete\n");
}