#ifndef SOCKET_IO_CLIENT_H
#define SOCKET_IO_CLIENT_H

#include <Arduino.h>
#include <map>
#include <vector>
#include <functional>

// Platform detection
#if defined(ESP8266)
  #include <BearSSLClient.h>
  #include <WebSocketsClient_Generic.h>
  #define SOCKET_IO_PLATFORM_ESP8266
#elif defined(ESP32)
  #include <WiFiClientSecure.h>
  #include <WebSocketsClient_Generic.h>
  #include <freertos/FreeRTOS.h>
  #include <freertos/task.h>
  #include <freertos/semphr.h>
  #define SOCKET_IO_PLATFORM_ESP32
#else
  #error "Unsupported platform"
#endif

// Debug configuration
//#define SOCKETIOCLIENT_DEBUG_ENABLE  // Uncomment to enable debugging

#ifdef SOCKETIOCLIENT_DEBUG_ENABLE
  #define SOCKETIOCLIENT_DEBUG(...) Serial.printf("[SIoC] " __VA_ARGS__)
#else
  #define SOCKETIOCLIENT_DEBUG(...)
#endif

// Buffer configuration
#if defined(SOCKET_IO_PLATFORM_ESP32)
  #define WS_RX_BUFFER_SIZE 4096
  #define WS_TX_BUFFER_SIZE 4096
#elif defined(SOCKET_IO_PLATFORM_ESP8266)
  #define WS_RX_BUFFER_SIZE 1024
  #define WS_TX_BUFFER_SIZE 1024
#endif

// Protocol constants
#define DEFAULT_PORT 443
#define DEFAULT_URL "/socket.io/?transport=websocket"
#define DEFAULT_FINGERPRINT ""
#define PING_INTERVAL 10000
#define SOCKET_IO_VERSION "0.3.2"

class SocketIoClient {
private:
    std::vector<String> _packets;
    std::map<String, std::function<void (const char * payload, size_t length)>> _events;
    
    #if defined(SOCKET_IO_PLATFORM_ESP32)
        WiFiClientSecure _sslClient;
        WebSocketsClient _webSocket; // Changed line
        TaskHandle_t _socketTask = NULL;
        SemaphoreHandle_t _mutex = NULL;
    #else
        WebSocketsClient _webSocket; // Changed line
    #endif

    unsigned long _lastPing;
    void trigger(const char* event, const char * payload, size_t length);
    void webSocketEvent(WStype_t type, uint8_t * payload, size_t length);
    void initialize();

public:
    SocketIoClient() {
      #if defined(SOCKET_IO_PLATFORM_ESP32) || defined(SOCKET_IO_PLATFORM_ESP8266)
        _webSocket.setBufferSizes(WS_RX_BUFFER_SIZE, WS_TX_BUFFER_SIZE);
      #endif
    }
    ~SocketIoClient();

    // Connection methods
    void beginSSL(const char* host, const int port = DEFAULT_PORT, 
                 const char* url = DEFAULT_URL, const char* fingerprint = DEFAULT_FINGERPRINT);
    void begin(const char* host, const int port = DEFAULT_PORT, 
              const char* url = DEFAULT_URL);

    // Core functionality
    void loop();
    void on(const char* event, std::function<void (const char * payload, size_t length)>);
    void emit(const char* event, const char * payload = NULL);
    void disconnect();
    
    // Security
    void setAuthorization(const char * user, const char * password);
    
    // ESP32-specific features
    #if defined(SOCKET_IO_PLATFORM_ESP32)
        void lowPowerMode(bool enable);
        void setCACert(const char* caCert);
        void setCertificate(const char* clientCert, const char* clientKey);
    #endif

    // Multi-threading control
    void lock();
    void unlock();
};

#endif